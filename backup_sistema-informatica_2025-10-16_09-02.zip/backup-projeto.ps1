# Script de backup e compactação do projeto
$dataAtual = Get-Date -Format "yyyy-MM-dd_HH-mm"
$nomeProjeto = "sistema-informatica"
$diretorioAtual = Get-Location
$diretorioBackup = Join-Path $diretorioAtual "backup_$nomeProjeto`_$dataAtual"
$arquivoZip = Join-Path $diretorioAtual "backup_$nomeProjeto`_$dataAtual.zip"

# Criar diretório de backup
Write-Host "Criando diretório de backup: $diretorioBackup" -ForegroundColor Cyan
New-Item -ItemType Directory -Path $diretorioBackup -Force | Out-Null

# Copiar arquivos para o diretório de backup (excluindo node_modules e outros diretórios grandes)
Write-Host "Copiando arquivos do projeto..." -ForegroundColor Cyan
$excludeDirs = @("node_modules", ".git", "build", "dist", "uploads")

# Função para copiar arquivos excluindo diretórios específicos
function Copy-ProjectFiles {
    param (
        [string]$Source,
        [string]$Destination,
        [array]$ExcludeDirs
    )
    
    # Criar o diretório de destino se não existir
    if (-not (Test-Path $Destination)) {
        New-Item -ItemType Directory -Path $Destination -Force | Out-Null
    }
    
    # Obter todos os itens no diretório de origem
    $items = Get-ChildItem -Path $Source -Force
    
    foreach ($item in $items) {
        $destPath = Join-Path $Destination $item.Name
        
        # Verificar se é um diretório a ser excluído
        if ($item.PSIsContainer -and $ExcludeDirs -contains $item.Name) {
            Write-Host "  Ignorando diretório: $($item.Name)" -ForegroundColor Yellow
            continue
        }
        
        if ($item.PSIsContainer) {
            # Se for diretório, chamar a função recursivamente
            Copy-ProjectFiles -Source $item.FullName -Destination $destPath -ExcludeDirs $ExcludeDirs
        } else {
            # Se for arquivo, copiar diretamente
            Copy-Item -Path $item.FullName -Destination $destPath -Force
        }
    }
}

# Iniciar cópia dos arquivos
Copy-ProjectFiles -Source $diretorioAtual -Destination $diretorioBackup -ExcludeDirs $excludeDirs

# Compactar o diretório de backup
Write-Host "Compactando o backup em: $arquivoZip" -ForegroundColor Cyan
Add-Type -AssemblyName System.IO.Compression.FileSystem
[System.IO.Compression.ZipFile]::CreateFromDirectory($diretorioBackup, $arquivoZip)

# Remover o diretório de backup temporário
Write-Host "Removendo diretório de backup temporário..." -ForegroundColor Cyan
Remove-Item -Path $diretorioBackup -Recurse -Force

# Verificar se o arquivo ZIP foi criado com sucesso
if (Test-Path $arquivoZip) {
    $tamanhoArquivo = (Get-Item $arquivoZip).Length / 1MB
    Write-Host "Backup concluído com sucesso!" -ForegroundColor Green
    Write-Host "Arquivo: $arquivoZip" -ForegroundColor Green
    Write-Host "Tamanho: $([math]::Round($tamanhoArquivo, 2)) MB" -ForegroundColor Green
} else {
    Write-Host "Erro ao criar o arquivo de backup!" -ForegroundColor Red
}