import axios from 'axios';

const API_URL = '/api/users/';

// Registrar usuário
const register = async (userData) => {
  const response = await axios.post(API_URL, userData);

  if (response.data) {
    localStorage.setItem('user', JSON.stringify(response.data));
    // Persistir token também em chave separada para consistência em fluxos diversos
    if (response.data.token) {
      localStorage.setItem('token', response.data.token);
    }
  }

  return response.data;
};

// Login de usuário
const login = async (userData) => {
  // Se for login de técnico, usar endpoint específico
  let endpoint = 'login';
  if (userData?.role === 'technician') {
    // Frontend passa loginId no campo email para reaproveitar UI atual?
    // Ajustado: aceitar userData.loginId quando presente
    endpoint = 'technician-login';
  }
  const payload = { ...userData };
  if (endpoint === 'technician-login') {
    // Passar cpfCnpj para backend quando login de técnico
    // Mantém compatibilidade: se vier loginId/email, ainda funciona
    if (userData.cpfCnpj) {
      payload.cpfCnpj = userData.cpfCnpj;
      delete payload.email;
      delete payload.loginId;
    } else if (userData.loginId || userData.email) {
      payload.loginId = userData.loginId || userData.email;
      delete payload.email;
    }
  }
  const response = await axios.post(API_URL + endpoint, payload);

  if (response.data) {
    localStorage.setItem('user', JSON.stringify(response.data));
    // Persistir token também em chave separada para consistência em fluxos diversos
    if (response.data.token) {
      localStorage.setItem('token', response.data.token);
    }
  }

  return response.data;
};


// Logout de usuário
const logout = async () => {
  try {
    const raw = localStorage.getItem('user');
    const user = raw ? JSON.parse(raw) : null;
    const token = user?.token || localStorage.getItem('token');
    if (token) {
      await axios.post(API_URL + 'logout', {}, {
        headers: { Authorization: `Bearer ${token}` },
      });
    }
  } catch (e) {
    // Ignorar erros de logout
  } finally {
    localStorage.removeItem('user');
    localStorage.removeItem('token');
  }
};

// Recuperação de senha
const forgotPassword = async (email) => {
  const response = await axios.post(API_URL + 'forgot-password', { email });
  return response.data;
};

const authService = {
  register,
  login,
  logout,
  forgotPassword,
};

export default authService;